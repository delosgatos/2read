var a=document.createElement("a");
document.body.appendChild(a);
a.innerText="USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME USE ME";
a.setAttribute("href", "//ya.ru");